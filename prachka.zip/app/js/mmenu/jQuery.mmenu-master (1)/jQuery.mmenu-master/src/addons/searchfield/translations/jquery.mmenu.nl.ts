(function( $ ) {

	const _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Search'			: 'Zoeken',
		'No results found.'	: 'Geen resultaten gevonden.',
		'cancel'			: 'annuleren'
	});

})( jQuery );